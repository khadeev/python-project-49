from brain_games.calc import brain_calc_game

def main():
    brain_calc_game()

if __name__ == '__main__':
    main()
