from brain_games.gcd import brain_gcd_game

def main():
    brain_gcd_game()

if __name__ == '__main__':
    main()
