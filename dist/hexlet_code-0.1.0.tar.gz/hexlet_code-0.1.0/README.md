### Hexlet tests and linter status:
[![Actions Status](https://github.com/khadeev/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/khadeev/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/8e641eece148a48aaedb/maintainability)](https://codeclimate.com/github/khadeev/python-project-49/maintainability)

[![asciicast](https://asciinema.org/a/MmGBB9TrTLFU2k8wegFyQyZb4.svg)](https://asciinema.org/a/MmGBB9TrTLFU2k8wegFyQyZb4)