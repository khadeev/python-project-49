from brain_games.even import brain_even_game

def main():
    brain_even_game()

if __name__ == '__main__':
    main()
