from brain_games.progression import brain_progression_game

def main():
    brain_progression_game()

if __name__ == '__main__':
    main()
